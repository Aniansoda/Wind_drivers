# 真机产物 (tools/device)

这里的文件**全部来自设备本身**，不是源码侧推测。

## config/android16-6.12.58-device.config
设备 `/proc/config.gz` 原样解压，8083 行。CI 直接拿它当 `.config` 种子
（`Configure kernel` 步骤的 `config_file`），所以 `CONFIG_CFI_CLANG=y`、
`KASAN_HW_TAGS=y`、`SHADOW_CALL_STACK=y`、`ANDROID_KABI_RESERVE=y` 这些
决定结构体布局和间接调用校验的开关与真机一致。

## symvers/android16-6.12.58-device.symvers
从设备 `/vendor_dlkm/lib/modules` 的 **454 个 vendor ko** 的 `__versions`
段 harvest 出来的真机 CRC 表，4690 个符号，`module_layout = 0x797f2b3e`。

```bash
tar xzf windpack-*.tar.gz -C /tmp/wpk
tar xzf /tmp/wpk/mods-vendor_dlkm.tar.gz -C /tmp/devmods
python3 tools/dump_kcrc.py harvest tools/device/symvers/<名>.symvers \
    $(find /tmp/devmods -name '*.ko')
```

CI 在 `Merge device CRCs` 里先用 `dump_kcrc.py count` 比一次：
`strict_crc: "1"` 的行要求**不一致数 = 0**，否则直接失败。
一致就说明源码 + config 与真机同构，编出来的 ko 不需要任何 CRC 手术。
